package spa.spaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpaserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpaserverApplication.class, args);
	}

}
